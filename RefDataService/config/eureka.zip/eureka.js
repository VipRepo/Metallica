import Eureka from 'eureka-js-client';


// example configuration 
const client = new Eureka({
 // application instance information 
 instance: {
   app: 'jqservice',
   hostName: 'localhost',
   ipAddr: '127.0.0.1',
   port: 9081,
   vipAddress: 'jq.test.something.com',
   dataCenterInfo: {
    name: 'MyOwn',
  }
 },       
 eureka: {
   // eureka server host / port 
   host: '10.207.101.61',
   port: 8761,
   servicePath: '/eureka/apps/',
 },
});

export default function connectToEureka() {               
    client.logger.level('debug');   
    client.start(function(error) {
    console.log('########################################################');
    console.log(JSON.stringify(error) || 'Eureka registration complete');   }); }
 